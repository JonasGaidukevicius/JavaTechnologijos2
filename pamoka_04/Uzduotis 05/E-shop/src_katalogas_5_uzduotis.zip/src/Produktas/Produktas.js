class Product{
    constructor(title, imageUrl, description, price, quantity){
        this.title = title;
        this.imageUrl = imageUrl;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
    }

}

export default Product;