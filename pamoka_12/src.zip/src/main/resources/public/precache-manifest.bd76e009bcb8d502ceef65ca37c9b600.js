self.__precacheManifest = [
  {
    "revision": "ea8e20931bce9c1d70d8303f6bcb1c2c",
    "url": "/static/media/KingWear-KW06.ea8e2093.jpg"
  },
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "1bc23f477dc0d6d25962",
    "url": "/static/js/main.1bc23f47.chunk.js"
  },
  {
    "revision": "8a23372cad78f8930bef",
    "url": "/static/js/1.8a23372c.chunk.js"
  },
  {
    "revision": "1bc23f477dc0d6d25962",
    "url": "/static/css/main.c69c860a.chunk.css"
  },
  {
    "revision": "8a23372cad78f8930bef",
    "url": "/static/css/1.141c386c.chunk.css"
  },
  {
    "revision": "c0ea3bd8290431ed43f2cb12d06c68f5",
    "url": "/index.html"
  }
];