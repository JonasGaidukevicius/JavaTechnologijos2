package it.akademija.vaisiai.db;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VaisiuRepozitorija extends JpaRepository<VaisiusDb, Long> {

}
